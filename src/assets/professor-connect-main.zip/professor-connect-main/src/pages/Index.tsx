import { useState } from "react";
import { AnimatePresence } from "framer-motion";
import { Header } from "@/components/Header";
import { Hero } from "@/components/Hero";
import { StepIndicator } from "@/components/StepIndicator";
import { UniversitySearch } from "@/components/UniversitySearch";
import { DepartmentSelect } from "@/components/DepartmentSelect";
import { EmailPreview } from "@/components/EmailPreview";
import { GeneratingState } from "@/components/GeneratingState";

const steps = [
  { id: 1, title: "University", description: "Select institution" },
  { id: 2, title: "Department", description: "Choose field" },
  { id: 3, title: "Preview", description: "Review email" },
  { id: 4, title: "Generate", description: "Create drafts" },
];

type AppState = "hero" | "university" | "department" | "preview" | "generating";

const Index = () => {
  const [appState, setAppState] = useState<AppState>("hero");
  const [selectedUniversity, setSelectedUniversity] = useState<string | null>(null);
  const [selectedDepartment, setSelectedDepartment] = useState<string | null>(null);

  const getCurrentStep = () => {
    switch (appState) {
      case "university":
        return 1;
      case "department":
        return 2;
      case "preview":
        return 3;
      case "generating":
        return 4;
      default:
        return 0;
    }
  };

  const handleGetStarted = () => {
    setAppState("university");
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <AnimatePresence mode="wait">
        {appState === "hero" && (
          <Hero key="hero" onGetStarted={handleGetStarted} />
        )}

        {appState !== "hero" && (
          <main className="pt-24 pb-16 px-6">
            {appState !== "generating" && (
              <StepIndicator steps={steps} currentStep={getCurrentStep()} />
            )}

            <AnimatePresence mode="wait">
              {appState === "university" && (
                <UniversitySearch
                  key="university"
                  selectedUniversity={selectedUniversity}
                  onSelect={setSelectedUniversity}
                  onNext={() => setAppState("department")}
                />
              )}

              {appState === "department" && selectedUniversity && (
                <DepartmentSelect
                  key="department"
                  selectedDepartment={selectedDepartment}
                  onSelect={setSelectedDepartment}
                  onNext={() => setAppState("preview")}
                  onBack={() => setAppState("university")}
                  university={selectedUniversity}
                />
              )}

              {appState === "preview" && selectedUniversity && selectedDepartment && (
                <EmailPreview
                  key="preview"
                  onBack={() => setAppState("department")}
                  onGenerate={() => setAppState("generating")}
                  university={selectedUniversity}
                  department={selectedDepartment}
                />
              )}

              {appState === "generating" && selectedUniversity && selectedDepartment && (
                <GeneratingState
                  key="generating"
                  university={selectedUniversity}
                  department={selectedDepartment}
                />
              )}
            </AnimatePresence>
          </main>
        )}
      </AnimatePresence>
    </div>
  );
};

export default Index;
