import { useEffect } from 'react';

const GoogleCallback = () => {
  useEffect(() => {
    // Parse the hash fragment for OAuth response
    const hash = window.location.hash.substring(1);
    const params = new URLSearchParams(hash);

    const accessToken = params.get('access_token');
    const expiresIn = params.get('expires_in');
    const state = params.get('state');
    const error = params.get('error');
    const errorDescription = params.get('error_description');

    // Verify state to prevent CSRF
    const storedState = localStorage.getItem('google_oauth_state');
    
    if (error) {
      window.opener?.postMessage({
        type: 'google-oauth-callback',
        error: errorDescription || error,
      }, window.location.origin);
      window.close();
      return;
    }

    if (state !== storedState) {
      window.opener?.postMessage({
        type: 'google-oauth-callback',
        error: 'Invalid state parameter. Please try again.',
      }, window.location.origin);
      window.close();
      return;
    }

    if (accessToken) {
      // Fetch user info to get email
      fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
        headers: {
          Authorization: `Bearer ${accessToken}`,
        },
      })
        .then(res => res.json())
        .then(userInfo => {
          window.opener?.postMessage({
            type: 'google-oauth-callback',
            accessToken,
            expiresIn: parseInt(expiresIn || '3600', 10),
            email: userInfo.email,
          }, window.location.origin);
          window.close();
        })
        .catch(() => {
          window.opener?.postMessage({
            type: 'google-oauth-callback',
            accessToken,
            expiresIn: parseInt(expiresIn || '3600', 10),
          }, window.location.origin);
          window.close();
        });
    } else {
      window.opener?.postMessage({
        type: 'google-oauth-callback',
        error: 'No access token received',
      }, window.location.origin);
      window.close();
    }

    // Clear state
    localStorage.removeItem('google_oauth_state');
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background">
      <div className="text-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
        <p className="text-muted-foreground">Completing authentication...</p>
      </div>
    </div>
  );
};

export default GoogleCallback;
