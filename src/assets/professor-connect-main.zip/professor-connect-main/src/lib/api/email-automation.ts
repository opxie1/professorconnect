import { supabase } from '@/integrations/supabase/client';

export interface FacultyMember {
  name: string;
  lastName: string;
  email: string | null;
  title: string;
  profileUrl: string;
  isResearchActive: boolean;
}

export interface AnalyzedFaculty extends FacultyMember {
  researchInterests: string;
}

export interface EmailDraft {
  professorName: string;
  email: string;
  subject: string;
  body: string;
  gmailComposeUrl: string;
  profileUrl?: string;
  success: boolean;
  error?: string;
}

export interface ScrapeFacultyResult {
  success: boolean;
  faculty?: FacultyMember[];
  totalFound?: number;
  researchActive?: number;
  error?: string;
}

export interface AnalyzeResearchResult {
  success: boolean;
  faculty?: AnalyzedFaculty[];
  error?: string;
}

export interface CreateDraftsResult {
  success: boolean;
  drafts?: EmailDraft[];
  successCount?: number;
  totalCount?: number;
  error?: string;
}

export const emailAutomationApi = {
  async scrapeFaculty(university: string, department: string): Promise<ScrapeFacultyResult> {
    const { data, error } = await supabase.functions.invoke('scrape-faculty', {
      body: { university, department },
    });

    if (error) {
      console.error('Error scraping faculty:', error);
      return { success: false, error: error.message };
    }

    return data;
  },

  async analyzeResearch(faculty: FacultyMember[]): Promise<AnalyzeResearchResult> {
    const { data, error } = await supabase.functions.invoke('analyze-research', {
      body: { faculty },
    });

    if (error) {
      console.error('Error analyzing research:', error);
      return { success: false, error: error.message };
    }

    return data;
  },

  async createGmailDrafts(faculty: AnalyzedFaculty[]): Promise<CreateDraftsResult> {
    const { data, error } = await supabase.functions.invoke('create-gmail-drafts', {
      body: { faculty },
    });

    if (error) {
      console.error('Error creating drafts:', error);
      return { success: false, error: error.message };
    }

    return data;
  },
};
