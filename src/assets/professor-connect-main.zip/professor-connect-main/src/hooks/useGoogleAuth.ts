import { useState, useEffect, useCallback } from 'react';

const GOOGLE_CLIENT_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID;
const SCOPES = 'https://www.googleapis.com/auth/gmail.compose https://www.googleapis.com/auth/gmail.modify';

interface GoogleAuthState {
  isAuthenticated: boolean;
  accessToken: string | null;
  userEmail: string | null;
  isLoading: boolean;
  error: string | null;
}

export const useGoogleAuth = () => {
  const [authState, setAuthState] = useState<GoogleAuthState>({
    isAuthenticated: false,
    accessToken: null,
    userEmail: null,
    isLoading: false,
    error: null,
  });

  // Check for existing token in localStorage
  useEffect(() => {
    const storedToken = localStorage.getItem('google_access_token');
    const storedEmail = localStorage.getItem('google_user_email');
    const tokenExpiry = localStorage.getItem('google_token_expiry');

    if (storedToken && tokenExpiry) {
      const expiryTime = parseInt(tokenExpiry, 10);
      if (Date.now() < expiryTime) {
        setAuthState({
          isAuthenticated: true,
          accessToken: storedToken,
          userEmail: storedEmail,
          isLoading: false,
          error: null,
        });
      } else {
        // Token expired, clear it
        localStorage.removeItem('google_access_token');
        localStorage.removeItem('google_user_email');
        localStorage.removeItem('google_token_expiry');
      }
    }
  }, []);

  const signIn = useCallback(() => {
    if (!GOOGLE_CLIENT_ID) {
      setAuthState(prev => ({
        ...prev,
        error: 'Google Client ID not configured. Please add VITE_GOOGLE_CLIENT_ID to your environment.',
      }));
      return;
    }

    setAuthState(prev => ({ ...prev, isLoading: true, error: null }));

    // Create OAuth URL
    const redirectUri = window.location.origin + '/auth/google/callback';
    const state = crypto.randomUUID();
    localStorage.setItem('google_oauth_state', state);

    const authUrl = new URL('https://accounts.google.com/o/oauth2/v2/auth');
    authUrl.searchParams.set('client_id', GOOGLE_CLIENT_ID);
    authUrl.searchParams.set('redirect_uri', redirectUri);
    authUrl.searchParams.set('response_type', 'token');
    authUrl.searchParams.set('scope', SCOPES);
    authUrl.searchParams.set('state', state);
    authUrl.searchParams.set('prompt', 'consent');
    authUrl.searchParams.set('access_type', 'online');

    // Open OAuth popup
    const width = 500;
    const height = 600;
    const left = window.screenX + (window.outerWidth - width) / 2;
    const top = window.screenY + (window.outerHeight - height) / 2;

    const popup = window.open(
      authUrl.toString(),
      'google-oauth',
      `width=${width},height=${height},left=${left},top=${top}`
    );

    // Listen for the callback
    const handleMessage = (event: MessageEvent) => {
      if (event.origin !== window.location.origin) return;
      
      if (event.data.type === 'google-oauth-callback') {
        const { accessToken, expiresIn, email, error } = event.data;
        
        if (error) {
          setAuthState(prev => ({
            ...prev,
            isLoading: false,
            error: error,
          }));
        } else if (accessToken) {
          const expiryTime = Date.now() + (expiresIn * 1000);
          localStorage.setItem('google_access_token', accessToken);
          localStorage.setItem('google_user_email', email || '');
          localStorage.setItem('google_token_expiry', expiryTime.toString());

          setAuthState({
            isAuthenticated: true,
            accessToken,
            userEmail: email,
            isLoading: false,
            error: null,
          });
        }

        window.removeEventListener('message', handleMessage);
        popup?.close();
      }
    };

    window.addEventListener('message', handleMessage);

    // Check if popup was closed without completing
    const checkClosed = setInterval(() => {
      if (popup?.closed) {
        clearInterval(checkClosed);
        window.removeEventListener('message', handleMessage);
        setAuthState(prev => {
          if (prev.isLoading) {
            return { ...prev, isLoading: false };
          }
          return prev;
        });
      }
    }, 500);
  }, []);

  const signOut = useCallback(() => {
    localStorage.removeItem('google_access_token');
    localStorage.removeItem('google_user_email');
    localStorage.removeItem('google_token_expiry');

    setAuthState({
      isAuthenticated: false,
      accessToken: null,
      userEmail: null,
      isLoading: false,
      error: null,
    });
  }, []);

  return {
    ...authState,
    signIn,
    signOut,
  };
};
