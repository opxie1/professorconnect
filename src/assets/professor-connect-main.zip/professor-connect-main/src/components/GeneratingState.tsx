import { useState } from "react";
import { motion } from "framer-motion";
import { Loader2, Sparkles, CheckCircle2, Mail, AlertCircle, ExternalLink } from "lucide-react";
import { Button } from "@/components/ui/button";
import { emailAutomationApi, type EmailDraft } from "@/lib/api/email-automation";
import { useToast } from "@/hooks/use-toast";

interface GeneratingStateProps {
  university: string;
  department: string;
}

type ProcessStep = {
  id: number;
  text: string;
  status: 'pending' | 'in-progress' | 'done' | 'error';
};

export const GeneratingState = ({ university, department }: GeneratingStateProps) => {
  const { toast } = useToast();

  const [processSteps, setProcessSteps] = useState<ProcessStep[]>([
    { id: 1, text: "Searching for faculty directory...", status: 'pending' },
    { id: 2, text: "Scraping professor profiles...", status: 'pending' },
    { id: 3, text: "Filtering research-active professors...", status: 'pending' },
    { id: 4, text: "Analyzing research interests with AI...", status: 'pending' },
    { id: 5, text: "Generating personalized emails...", status: 'pending' },
  ]);
  
  const [stats, setStats] = useState({
    professorsFound: 0,
    researchActive: 0,
    draftsCreated: 0,
  });

  const [isProcessing, setIsProcessing] = useState(false);
  const [isComplete, setIsComplete] = useState(false);
  const [drafts, setDrafts] = useState<EmailDraft[]>([]);
  const [error, setError] = useState<string | null>(null);

  const updateStep = (id: number, status: ProcessStep['status']) => {
    setProcessSteps(prev => prev.map(step => 
      step.id === id ? { ...step, status } : step
    ));
  };

  const runAutomation = async () => {
    setIsProcessing(true);
    setError(null);

    try {
      // Step 1 & 2: Scrape faculty
      updateStep(1, 'in-progress');
      
      const scrapeResult = await emailAutomationApi.scrapeFaculty(university, department);
      
      if (!scrapeResult.success || !scrapeResult.faculty) {
        updateStep(1, 'error');
        throw new Error(scrapeResult.error || 'Failed to scrape faculty directory');
      }

      updateStep(1, 'done');
      updateStep(2, 'done');
      setStats(prev => ({ ...prev, professorsFound: scrapeResult.totalFound || 0 }));

      // Step 3: Filter research-active (emails are optional; some directories hide them)
      updateStep(3, 'in-progress');
      const researchActiveFaculty = scrapeResult.faculty.filter(f => f.isResearchActive);
      setStats(prev => ({ ...prev, researchActive: researchActiveFaculty.length }));
      updateStep(3, 'done');

      if (researchActiveFaculty.length === 0) {
        throw new Error('No research-active professors found. Try a different department.');
      }

      // Step 4: Analyze research interests
      updateStep(4, 'in-progress');
      
      const analyzeResult = await emailAutomationApi.analyzeResearch(researchActiveFaculty);
      
      if (!analyzeResult.success || !analyzeResult.faculty) {
        updateStep(4, 'error');
        throw new Error(analyzeResult.error || 'Failed to analyze research interests');
      }

      updateStep(4, 'done');

      // Step 5: Create Gmail drafts
      updateStep(5, 'in-progress');
      
      const draftsResult = await emailAutomationApi.createGmailDrafts(analyzeResult.faculty);
      
      if (!draftsResult.success) {
        updateStep(5, 'error');
        throw new Error(draftsResult.error || 'Failed to create email drafts');
      }

      updateStep(5, 'done');
      setStats(prev => ({ ...prev, draftsCreated: draftsResult.successCount || 0 }));
      setDrafts(draftsResult.drafts || []);
      setIsComplete(true);

      toast({
        title: "Success!",
        description: draftsResult.successCount
          ? `Generated ${draftsResult.successCount} personalized emails ready to send!`
          : `Generated drafts, but some professors are missing public email addresses.`,
      });

    } catch (err) {
      console.error('Automation error:', err);
      setError(err instanceof Error ? err.message : 'An unexpected error occurred');
      toast({
        title: "Error",
        description: err instanceof Error ? err.message : 'Failed to complete automation',
        variant: "destructive",
      });
    } finally {
      setIsProcessing(false);
    }
  };

  const getStepIcon = (status: ProcessStep['status']) => {
    switch (status) {
      case 'done':
        return <CheckCircle2 className="w-5 h-5 text-primary" />;
      case 'in-progress':
        return (
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          >
            <Loader2 className="w-5 h-5 text-primary" />
          </motion.div>
        );
      case 'error':
        return <AlertCircle className="w-5 h-5 text-destructive" />;
      default:
        return <div className="w-5 h-5 rounded-full border-2 border-muted" />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="w-full max-w-lg mx-auto text-center"
    >
      <div className="glass-card p-8">
        {/* Animated icon */}
        <motion.div
          animate={{ rotate: isProcessing ? 360 : 0 }}
          transition={{ duration: 2, repeat: isProcessing ? Infinity : 0, ease: "linear" }}
          className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6"
        >
          {isComplete ? (
            <CheckCircle2 className="w-10 h-10 text-primary" />
          ) : (
            <Sparkles className="w-10 h-10 text-primary" />
          )}
        </motion.div>

        <h2 className="text-2xl font-semibold mb-2">
          {isComplete ? "Emails Generated!" : "Email Automation"}
        </h2>
        <p className="text-muted-foreground mb-6">
          {department} at {university}
        </p>


        {/* Progress steps */}
        <div className="space-y-4 text-left mb-8">
          {processSteps.map((step, index) => (
            <motion.div
              key={step.id}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-center gap-3"
            >
              {getStepIcon(step.status)}
              <span className={
                step.status === 'done' || step.status === 'in-progress' 
                  ? "text-foreground" 
                  : step.status === 'error' 
                    ? "text-destructive" 
                    : "text-muted-foreground"
              }>
                {step.text}
              </span>
            </motion.div>
          ))}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 p-4 rounded-xl bg-muted/50 mb-6">
          <div className="text-center">
            <motion.div
              key={stats.professorsFound}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring" }}
              className="text-2xl font-bold text-primary"
            >
              {stats.professorsFound}
            </motion.div>
            <p className="text-xs text-muted-foreground">Found</p>
          </div>
          <div className="text-center">
            <motion.div
              key={stats.researchActive}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring" }}
              className="text-2xl font-bold text-accent"
            >
              {stats.researchActive}
            </motion.div>
            <p className="text-xs text-muted-foreground">Research Active</p>
          </div>
          <div className="text-center">
            <motion.div
              key={stats.draftsCreated}
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring" }}
              className="text-2xl font-bold text-primary"
            >
              {stats.draftsCreated}
            </motion.div>
            <p className="text-xs text-muted-foreground">Drafts</p>
          </div>
        </div>

        {/* Error display */}
        {error && (
          <div className="p-4 rounded-xl bg-destructive/10 text-destructive text-sm mb-6">
            {error}
          </div>
        )}

        {/* Action buttons */}
        {!isComplete && !isProcessing && (
          <Button 
            onClick={runAutomation}
            className="w-full"
            size="lg"
          >
            <Sparkles className="w-4 h-4 mr-2" />
            Start Automation
          </Button>
        )}

        {isComplete && (
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">
              {stats.draftsCreated} personalized emails are ready! Click on any professor below to open the email in Gmail.
            </p>
          </div>
        )}

        {/* Info text */}
        {isProcessing && (
          <p className="text-xs text-muted-foreground mt-6">
            This may take a few minutes depending on the number of professors...
          </p>
        )}
      </div>

      {/* Drafts list */}
      {isComplete && drafts.length > 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-6 glass-card p-6 text-left"
        >
          <h3 className="font-semibold mb-4">Click to Open in Gmail</h3>
          <div className="space-y-3 max-h-96 overflow-y-auto">
            {drafts.map((draft, index) => {
              const isMissingEmail = !draft.success;
              return (
                <div
                  key={index}
                  className="p-3 rounded-lg bg-primary/5"
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <Mail className="w-4 h-4 text-primary" />
                      <div>
                        <div className="font-medium">{draft.professorName}</div>
                        {draft.email ? (
                          <p className="text-xs text-muted-foreground mt-1">{draft.email}</p>
                        ) : (
                          <p className="text-xs text-muted-foreground mt-1">
                            Email not publicly listed — you can still open a draft and add the recipient.
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      {draft.profileUrl && (
                        <a
                          href={draft.profileUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-xs underline text-muted-foreground hover:text-foreground transition-colors"
                        >
                          Profile
                        </a>
                      )}
                      <a
                        href={draft.gmailComposeUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className={
                          isMissingEmail
                            ? "text-xs underline text-muted-foreground hover:text-foreground transition-colors"
                            : "text-xs underline text-primary hover:text-primary/80 transition-colors"
                        }
                      >
                        Open Draft
                      </a>
                      <ExternalLink className="w-3 h-3 text-muted-foreground" />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </motion.div>
      )}
    </motion.div>
  );
};
