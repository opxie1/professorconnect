import { useState } from "react";
import { motion } from "framer-motion";
import { BookOpen, Search, Check, ChevronLeft } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { departments } from "@/data/universities";
import { cn } from "@/lib/utils";

interface DepartmentSelectProps {
  selectedDepartment: string | null;
  onSelect: (department: string) => void;
  onNext: () => void;
  onBack: () => void;
  university: string;
}

export const DepartmentSelect = ({
  selectedDepartment,
  onSelect,
  onNext,
  onBack,
  university,
}: DepartmentSelectProps) => {
  const [search, setSearch] = useState("");

  const filteredDepartments = departments.filter((dept) =>
    dept.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="w-full max-w-2xl mx-auto"
    >
      <div className="glass-card p-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ChevronLeft className="w-4 h-4" />
          Back to university
        </button>

        <div className="flex items-center gap-3 mb-2">
          <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center">
            <BookOpen className="w-6 h-6 text-accent" />
          </div>
          <div>
            <h2 className="text-2xl font-semibold">Select Department</h2>
            <p className="text-muted-foreground text-sm">
              at {university}
            </p>
          </div>
        </div>

        <p className="text-muted-foreground mb-6">
          Choose the academic department you want to reach out to
        </p>

        {/* Search */}
        <div className="relative mb-4">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search departments..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-12 h-12 rounded-xl"
          />
        </div>

        {/* Department grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 max-h-64 overflow-y-auto mb-6">
          {filteredDepartments.map((department, index) => (
            <motion.button
              key={department}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.02 }}
              onClick={() => onSelect(department)}
              className={cn(
                "px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 text-left",
                "border hover:border-primary/50 hover:bg-primary/5",
                selectedDepartment === department
                  ? "border-primary bg-primary/10 text-primary"
                  : "border-border"
              )}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="truncate">{department}</span>
                {selectedDepartment === department && (
                  <Check className="w-4 h-4 flex-shrink-0" />
                )}
              </div>
            </motion.button>
          ))}
        </div>

        {/* Continue button */}
        <Button
          variant="hero"
          className="w-full"
          disabled={!selectedDepartment}
          onClick={onNext}
        >
          Continue to Email Preview
        </Button>
      </div>
    </motion.div>
  );
};
