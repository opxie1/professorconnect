import { useState } from "react";
import { motion } from "framer-motion";
import { Mail, Paperclip, ChevronLeft, Send, User, Sparkles, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface EmailPreviewProps {
  onBack: () => void;
  onGenerate: () => void;
  university: string;
  department: string;
}

// Sample professor data for preview
const sampleProfessor = {
  name: "Dr. Sarah Chen",
  lastName: "Chen",
  email: "schen@university.edu",
  researchInterests: "machine learning and computational neuroscience",
  title: "Associate Professor",
  isResearch: true,
};

export const EmailPreview = ({
  onBack,
  onGenerate,
  university,
  department,
}: EmailPreviewProps) => {
  const [activeTab, setActiveTab] = useState<"template" | "preview">("preview");

  const emailTemplate = `Subject: Inquiry About Research or Internship Opportunity

Dear Professor ${sampleProfessor.lastName},

I hope you are doing well. My name is Ethan Xie, and I am currently a high school student at The Charter School of Wilmington in Wilmington, Delaware. I am reaching out to inquire if there is a potential opportunity, paid or unpaid, for me to act as an intern or assistant for you, or if I could work alongside you with a potential research study. I am particularly interested in ${sampleProfessor.researchInterests}, as well as data science and analytics.

I currently work with the Lemelson–MIT Program, assisting in the development of a Bluetooth-enabled ostomy leak alert and leading the system architecture design, including separating detection logic using convolutional neural network-based machine learning on an Arduino. Furthermore, I have extensive experience with C, C++, Python, Pandas, Tensorflow, and NumPy, alongside many other skills that could prove useful to you.

I also placed 2nd out of 250 teams internationally in the Financial Portfolio Management competition hosted by Business Professionals of America (BPA). In this competition, I led a team of 3 other students to create an investment strategy that maximized returns over 4 months. We valued companies through intrinsic and relative valuation methods and used metrics like the Sharpe ratio to evaluate the risk-adjusted performance of our portfolio. We ultimately achieved an 18% return through an aggressive equity allocation. In the final round, we presented our investment thesis and portfolio strategy to a panel of industry professionals, explaining our approach and answering any questions they had.

I am very enthusiastic about contributing to a potential research study or assisting you with your work, and I am confident that my experience would make me a valuable addition. I am willing to contribute up to 30 hours a week to assist with any tasks or projects you may need help with.

I would greatly appreciate your consideration if there is an opportunity for me. I thank you for your time and would be honored to discuss any potential opportunities with you further. Please let me know if there is a good time for us to meet or if you would like me to provide any documents or materials.

Additionally, I have attached my resume, which outlines more of my experience and background.

Hope to hear from you soon.

Sincerely,
Ethan Xie`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="w-full max-w-4xl mx-auto"
    >
      <div className="glass-card p-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors mb-6"
        >
          <ChevronLeft className="w-4 h-4" />
          Back to department
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
            <Mail className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h2 className="text-2xl font-semibold">Email Preview</h2>
            <p className="text-muted-foreground text-sm">
              {department} at {university}
            </p>
          </div>
        </div>

        {/* Info banner */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="p-4 rounded-xl bg-accent/10 border border-accent/20 mb-6"
        >
          <div className="flex items-start gap-3">
            <Sparkles className="w-5 h-5 text-accent mt-0.5" />
            <div>
              <p className="font-medium text-sm">AI-Powered Personalization</p>
              <p className="text-sm text-muted-foreground">
                Each email will be personalized with the professor's research interests analyzed from their publications and university profile.
              </p>
            </div>
          </div>
        </motion.div>

        {/* Sample professor card */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="p-4 rounded-xl border border-border bg-card mb-6"
        >
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center">
              <User className="w-7 h-7 text-primary" />
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <h3 className="font-semibold">{sampleProfessor.name}</h3>
                <span className="px-2 py-0.5 rounded-full bg-primary/10 text-primary text-xs font-medium">
                  Research Active
                </span>
              </div>
              <p className="text-sm text-muted-foreground">{sampleProfessor.title}</p>
              <p className="text-sm text-muted-foreground">{sampleProfessor.email}</p>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-border">
            <p className="text-xs text-muted-foreground mb-1">Research Interests (AI-analyzed):</p>
            <p className="text-sm font-medium text-primary">{sampleProfessor.researchInterests}</p>
          </div>
        </motion.div>

        {/* Tabs */}
        <div className="flex gap-2 mb-4">
          {["preview", "template"].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab as "template" | "preview")}
              className={cn(
                "px-4 py-2 rounded-lg text-sm font-medium transition-all",
                activeTab === tab
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:bg-muted/80"
              )}
            >
              {tab === "preview" ? "Email Preview" : "Raw Template"}
            </button>
          ))}
        </div>

        {/* Email content */}
        <motion.div
          key={activeTab}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="rounded-xl border border-border bg-card overflow-hidden"
        >
          {/* Email header */}
          <div className="p-4 border-b border-border bg-muted/30">
            <div className="space-y-2 text-sm">
              <div className="flex gap-2">
                <span className="text-muted-foreground w-16">To:</span>
                <span className="font-medium">{sampleProfessor.email}</span>
              </div>
              <div className="flex gap-2">
                <span className="text-muted-foreground w-16">Subject:</span>
                <span className="font-medium">Inquiry About Research or Internship Opportunity</span>
              </div>
              <div className="flex gap-2 items-center">
                <span className="text-muted-foreground w-16">Attach:</span>
                <div className="flex items-center gap-2 px-3 py-1 rounded-lg bg-primary/10 text-primary text-xs">
                  <Paperclip className="w-3 h-3" />
                  <span>Ethan_Xie.pdf</span>
                </div>
              </div>
            </div>
          </div>

          {/* Email body */}
          <div className="p-6 max-h-80 overflow-y-auto">
            <pre className="whitespace-pre-wrap font-sans text-sm leading-relaxed">
              {emailTemplate.split('\n').slice(2).join('\n')}
            </pre>
          </div>
        </motion.div>

        {/* Action buttons */}
        <div className="mt-6 flex gap-4">
          <Button
            variant="heroOutline"
            className="flex-1"
            onClick={onBack}
          >
            <FileText className="w-4 h-4" />
            Edit Template
          </Button>
          <Button
            variant="hero"
            className="flex-1"
            onClick={onGenerate}
          >
            <Send className="w-4 h-4" />
            Generate Drafts
          </Button>
        </div>

        <p className="text-xs text-muted-foreground text-center mt-4">
          Gmail drafts will be created for each research-active professor in the {department} department.
        </p>
      </div>
    </motion.div>
  );
};
