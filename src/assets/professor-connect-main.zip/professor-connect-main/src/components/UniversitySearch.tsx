import { useState, useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Search, GraduationCap, X, Check } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { universities } from "@/data/universities";
import { cn } from "@/lib/utils";

interface UniversitySearchProps {
  selectedUniversity: string | null;
  onSelect: (university: string) => void;
  onNext: () => void;
}

export const UniversitySearch = ({ 
  selectedUniversity, 
  onSelect, 
  onNext 
}: UniversitySearchProps) => {
  const [search, setSearch] = useState("");
  const [isOpen, setIsOpen] = useState(false);

  const filteredUniversities = useMemo(() => {
    if (!search) return universities.slice(0, 20);
    const searchLower = search.toLowerCase();
    return universities
      .filter(uni => uni.toLowerCase().includes(searchLower))
      .slice(0, 20);
  }, [search]);

  const handleSelect = (university: string) => {
    onSelect(university);
    setSearch("");
    setIsOpen(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="w-full max-w-2xl mx-auto"
    >
      <div className="glass-card p-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
            <GraduationCap className="w-6 h-6 text-primary" />
          </div>
          <div>
            <h2 className="text-2xl font-semibold">Select University</h2>
            <p className="text-muted-foreground">
              Choose the university where professors teach
            </p>
          </div>
        </div>

        {/* Selected university display */}
        <AnimatePresence>
          {selectedUniversity && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              className="mb-4"
            >
              <div className="flex items-center justify-between p-4 rounded-lg bg-primary/5 border border-primary/20">
                <div className="flex items-center gap-3">
                  <Check className="w-5 h-5 text-primary" />
                  <span className="font-medium">{selectedUniversity}</span>
                </div>
                <button 
                  onClick={() => onSelect("")}
                  className="p-1 hover:bg-primary/10 rounded-full transition-colors"
                >
                  <X className="w-4 h-4 text-muted-foreground" />
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Search input */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
          <Input
            type="text"
            placeholder="Search 2,000+ universities..."
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setIsOpen(true);
            }}
            onFocus={() => setIsOpen(true)}
            className="pl-12 h-14 text-lg rounded-xl border-2 focus:border-primary transition-colors"
          />
        </div>

        {/* Dropdown */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="mt-2 rounded-xl border border-border bg-card shadow-lg overflow-hidden max-h-72 overflow-y-auto"
            >
              {filteredUniversities.length > 0 ? (
                filteredUniversities.map((university, index) => (
                  <motion.button
                    key={university}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: index * 0.02 }}
                    onClick={() => handleSelect(university)}
                    className={cn(
                      "w-full px-4 py-3 text-left hover:bg-accent/50 transition-colors flex items-center gap-3",
                      selectedUniversity === university && "bg-primary/5"
                    )}
                  >
                    <GraduationCap className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                    <span className="truncate">{university}</span>
                    {selectedUniversity === university && (
                      <Check className="w-4 h-4 text-primary ml-auto" />
                    )}
                  </motion.button>
                ))
              ) : (
                <div className="px-4 py-6 text-center text-muted-foreground">
                  No universities found matching "{search}"
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

        {/* Continue button */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: selectedUniversity ? 1 : 0.5 }}
          className="mt-6"
        >
          <Button
            variant="hero"
            className="w-full"
            disabled={!selectedUniversity}
            onClick={onNext}
          >
            Continue to Department Selection
          </Button>
        </motion.div>
      </div>
    </motion.div>
  );
};
