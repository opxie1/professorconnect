import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface FacultyMember {
  name: string;
  lastName: string;
  email: string | null;
  title: string;
  profileUrl: string;
  isResearchActive: boolean;
}

function normalizeUrl(url: string, fallbackBase?: string): string {
  try {
    if (url.startsWith('http://') || url.startsWith('https://')) return url;
    if (!fallbackBase) return url;
    return new URL(url, fallbackBase).toString();
  } catch {
    return url;
  }
}

function getHostname(url: string): string | null {
  try {
    return new URL(url).hostname.toLowerCase();
  } catch {
    return null;
  }
}

function isBadDiscoveryHost(host: string): boolean {
  const bad = [
    'wikipedia.org',
    'linkedin.com',
    'facebook.com',
    'twitter.com',
    'x.com',
    'instagram.com',
  ];
  return bad.some(d => host === d || host.endsWith(`.${d}`));
}

function looksLikePersonName(name: string, department: string): boolean {
  const n = name.trim();
  if (n.length < 5) return false;

  // Must look like at least first + last name
  const parts = n.split(/\s+/).filter(Boolean);
  if (parts.length < 2) return false;

  // First + last should usually start uppercase (filters many false positives)
  const first = parts[0];
  const last = parts[parts.length - 1];
  const startsUpper = (s: string) => /^[A-Z]/.test(s);
  const isInitial = (s: string) => /^[A-Z]\.?$/.test(s);
  if (!(startsUpper(first) || isInitial(first))) return false;
  if (!startsUpper(last) && !isInitial(last)) return false;

  // Reject if it's basically the department label (common false positive)
  const dep = department.trim().toLowerCase();
  if (dep && n.toLowerCase() === dep) return false;

  // Reject obvious non-person tokens
  const lower = n.toLowerCase();
  const badTokens = [
    'faculty', 'directory', 'people', 'staff', 'contact', 'office', 'team', 'finance',
    'admissions', 'news', 'research', 'academics', 'program', 'department', 'center',
    'coordinator', 'advisor', 'assistant to',
  ];
  if (badTokens.some(t => lower === t)) return false;

  // Reject if it contains lots of punctuation/URL-ish content
  if (/[\/|<>{}]/.test(n)) return false;

  return true;
}

function extractEmail(text: string): string | null {
  const match = text.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/);
  return match ? match[1].trim() : null;
}

function isResearchActiveFromText(text: string): boolean {
  const t = text.toLowerCase();
  const excluded = ['emeritus', 'adjunct', 'visiting', 'lecturer', 'practice'];
  if (excluded.some(w => t.includes(w))) return false;
  // Default to active if it looks like professor/academic staff
  const include = ['professor', 'chair', 'assistant professor', 'associate professor', 'research'];
  return include.some(w => t.includes(w));
}

// Note: many directories omit titles; we treat missing titles as "Professor" later.

// Extract faculty data from markdown using regex patterns
function extractFacultyFromMarkdown(markdown: string, baseUrl: string, department: string): FacultyMember[] {
  const faculty: FacultyMember[] = [];
  
  // Split by list items and process each
  const lines = markdown.split('\n');
  
  for (const line of lines) {
    // Pattern: - **[Name](url)**, Title [Email email](mailto:email)
    // Example: - **[Andrew B. Abel](https://fnce.wharton.upenn.edu/profile/abel)**, Ronald A. Rosenfeld Professor, Professor of Finance [Email abel@wharton.upenn.edu](mailto:abel@wharton.upenn.edu)
    
    const nameMatch = line.match(/\*\*\[([^\]]+)\]\(([^)]+)\)\*\*/);
    if (!nameMatch) continue;
    
    const name = nameMatch[1].trim();
    const profileUrl = normalizeUrl(nameMatch[2], baseUrl);
    if (!looksLikePersonName(name, department)) continue;
    
    // Extract email - look for [Email xxx](mailto:xxx) or just an email pattern
    const emailMatch = line.match(/\[Email\s+([^\]]+)\]/) || line.match(/mailto:([^)\s]+)/);
    const email = (emailMatch ? emailMatch[1].replace('mailto:', '').trim() : null) || extractEmail(line);
    
    // Extract title - everything between the closing ** and the [Email or end
    const afterName = line.split('**')[2] || '';
    let title = afterName.split('[Email')[0].replace(/^[,\s]+/, '').trim();
    if (!title) {
      title = 'Professor';
    }
    
    // Check if research-active
    const fullText = `${title} ${line}`;
    const isResearchActive = isResearchActiveFromText(fullText);
    
    // Skip non-person entries
    const lowerName = name.toLowerCase();
    if (lowerName.includes('position') || 
        lowerName.includes('news') || 
        lowerName.includes('staff') ||
        lowerName.includes('office') ||
        lowerName.includes('department') ||
        lowerName.includes('contact')) {
      continue;
    }
    
    if (name && name.length > 2) {
      faculty.push({
        name,
        lastName: name.split(' ').pop() || name,
        email,
        title,
        profileUrl,
        isResearchActive,
      });
    }
  }

  // Also try pattern for ## [Name](url) format
   const pattern2 = /##\s*\[([^\]]+)\]\(([^)]+)\)\s*\n+([^\n#\[]+)/g;
  let match;
  
  while ((match = pattern2.exec(markdown)) !== null) {
     const name = match[1].trim();
     const profileUrl = normalizeUrl(match[2], baseUrl);
    const title = match[3].trim();
     if (!looksLikePersonName(name, department)) continue;
    
    // Check if already added
    if (name && name.length > 2 && !faculty.some(f => f.name === name)) {
       const isResearchActive = isResearchActiveFromText(title);
      
      faculty.push({
        name,
        lastName: name.split(' ').pop() || name,
        email: null,
        title: title || 'Professor',
        profileUrl,
        isResearchActive,
      });
    }
  }

  return faculty;
}

async function scrapeMarkdown(apiKey: string, url: string) {
  const resp = await fetch('https://api.firecrawl.dev/v1/scrape', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      url,
      formats: ['markdown'],
      onlyMainContent: true,
      // Helps for JS-heavy pages
      waitFor: 800,
    }),
  });
  const data = await resp.json();
  return {
    ok: resp.ok,
    data,
    markdown: data.data?.markdown || data.markdown || '',
  };
}

async function scrapeFacultyJson(apiKey: string, url: string, university: string, department: string) {
  const resp = await fetch('https://api.firecrawl.dev/v1/scrape', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      url,
      onlyMainContent: true,
      waitFor: 1200,
      formats: [
        {
          type: 'json',
          prompt: `You are extracting faculty/professor contact info.

Target: ${department} faculty at ${university}.

Return ONLY a TOP-LEVEL JSON ARRAY of objects with these keys:
- name (string, full name)
- title (string)
- email (string|null)
- profileUrl (string|null) (link to that person's profile page if present)

Rules:
- ONLY include real people (professors/faculty). Exclude coordinators, advisors, staff, administrators, students.
- Prefer entries that clearly belong to the ${department} area.
- If email is not visible, set it to null.
- If profileUrl is relative, keep it as-is (we'll resolve it).
`
        }
      ],
    }),
  });

  const data = await resp.json();
  const extracted = data.data?.json || data.json;
  return { ok: resp.ok, extracted, raw: data };
}

function getUniversityAliases(university: string): string[] {
  const u = university.trim();
  const aliases = new Set<string>([u]);

  // Common normalization
  aliases.add(u.replace(/\s+\(.*\)$/g, '').trim());
  aliases.add(u.replace(/^University of\s+/i, '').trim());
  aliases.add(u.replace(/,\s*[^,]+$/g, '').trim());

  // Heuristic: "Institute of Technology" -> "Tech" (e.g. Georgia Tech)
  if (/Institute of Technology/i.test(u)) {
    aliases.add(u.replace(/Institute of Technology/i, 'Tech').trim());
  }

  return Array.from(aliases).filter(Boolean).slice(0, 3);
}

async function discoverUniversityDomain(apiKey: string, university: string): Promise<string | null> {
  // Find the most likely official .edu domain, then lock subsequent searches to it.
  const q = `${university} official site:.edu`;
  const resp = await fetch('https://api.firecrawl.dev/v1/search', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ query: q, limit: 6 }),
  });
  const data = await resp.json();
  if (!resp.ok || !data?.success) return null;

  for (const r of data.data || []) {
    const url = r?.url;
    const host = url ? getHostname(url) : null;
    if (!host) continue;
    if (isBadDiscoveryHost(host)) continue;
    if (!host.endsWith('.edu')) continue;
    return host;
  }

  return null;
}

function coerceExtractedArray(extracted: any): any[] {
  if (!extracted) return [];

  // Sometimes comes back as a JSON string
  if (typeof extracted === 'string') {
    try {
      const parsed = JSON.parse(extracted);
      return coerceExtractedArray(parsed);
    } catch {
      return [];
    }
  }

  if (Array.isArray(extracted)) return extracted;
  if (Array.isArray(extracted.faculty)) return extracted.faculty;
  if (Array.isArray(extracted.people)) return extracted.people;
  if (Array.isArray(extracted.professors)) return extracted.professors;
  if (Array.isArray(extracted.results)) return extracted.results;
  return [];
}

async function withConcurrency<T, R>(items: T[], limit: number, fn: (item: T) => Promise<R>): Promise<R[]> {
  const results: R[] = [];
  let index = 0;

  const workers = Array.from({ length: Math.max(1, limit) }, async () => {
    while (index < items.length) {
      const current = items[index++];
      try {
        results.push(await fn(current));
      } catch {
        // ignore individual failures
      }
    }
  });

  await Promise.all(workers);
  return results;
}

async function enrichMissingEmails(
  apiKey: string,
  university: string,
  department: string,
  faculty: FacultyMember[],
): Promise<FacultyMember[]> {
  const missing = faculty
    .filter(f => !f.email && f.profileUrl && looksLikePersonName(f.name, department))
    .slice(0, 12);

  if (missing.length === 0) return faculty;

  console.log(`Enriching emails for ${missing.length} faculty via profile pages...`);

  const updates = await withConcurrency(missing, 4, async (member) => {
    // 1) Try scraping the profile page directly
    const scraped = await scrapeMarkdown(apiKey, member.profileUrl);
    if (scraped.ok && scraped.markdown) {
      const email = extractEmail(scraped.markdown);
      if (email) {
        return { key: member.name, email };
      }
    }
    return { key: member.name, email: null };
  });

  const emailByName = new Map<string, string>();
  for (const u of updates) {
    if (u?.email) emailByName.set(u.key, u.email);
  }

  return faculty.map(m => ({
    ...m,
    email: m.email || emailByName.get(m.name) || null,
  }));
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { university, department } = await req.json();
    console.log(`Scraping faculty for ${department} at ${university}`);

    const apiKey = Deno.env.get('FIRECRAWL_API_KEY');
    if (!apiKey) {
      console.error('FIRECRAWL_API_KEY not configured');
      return new Response(
        JSON.stringify({ success: false, error: 'Firecrawl connector not configured' }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Discovery: find likely directory pages (fast search; no scraping content here)
    const universityDomain = await discoverUniversityDomain(apiKey, university);
    console.log('Discovered university domain:', universityDomain);

    const universityAliases = getUniversityAliases(university);
    const siteFilter = universityDomain ? `site:${universityDomain}` : 'site:.edu';
    const queryPatterns = [
      (u: string) => `${u} ${department} faculty directory ${siteFilter}`,
      (u: string) => `${u} ${department} faculty email ${siteFilter}`,
      (u: string) => `${u} ${department} professor mailto ${siteFilter}`,
      (u: string) => `${department} faculty directory ${siteFilter}`,
    ];
    const discoveryQueries = universityAliases.flatMap(u => queryPatterns.map(p => p(u)));

    const candidateUrls: string[] = [];
    const seenUrl = new Set<string>();

    for (const q of discoveryQueries) {
      console.log('Searching for:', q);
      const searchResponse = await fetch('https://api.firecrawl.dev/v1/search', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ query: q, limit: 6 }),
      });
      const searchData = await searchResponse.json();
      if (!searchResponse.ok || !searchData?.success) {
        console.error('Search failed:', searchData);
        continue;
      }
      for (const r of searchData.data || []) {
        const url = r?.url;
        if (!url || seenUrl.has(url)) continue;
        seenUrl.add(url);
        candidateUrls.push(url);
      }
    }

    const topUrls = candidateUrls.slice(0, 6);
    console.log('Candidate directory URLs:', topUrls);

    // Primary extraction: JSON extraction on a handful of top URLs
    const jsonResults = await withConcurrency(topUrls, 2, async (url) => {
      console.log('JSON extracting faculty from:', url);
      const res = await scrapeFacultyJson(apiKey, url, university, department);
      return { url, ...res };
    });

    // Convert JSON extraction into FacultyMember[] and pick the best one
    const parsedCandidates: { url: string; faculty: FacultyMember[]; score: number }[] = [];
    for (const r of jsonResults) {
      const arr = coerceExtractedArray(r.extracted);
      const facultyFromJson: FacultyMember[] = [];

      for (const p of arr) {
        const name = (p?.name || p?.fullName || p?.fullname || '').toString().trim();
        const title = (p?.title || p?.position || 'Professor').toString().trim();
        const email = (p?.email || p?.mail || null) ? String(p.email || p.mail).trim() : null;
        const profileUrl = normalizeUrl(
          String(p?.profileUrl || p?.profileURL || p?.url || p?.link || r.url),
          r.url,
        );

        if (!name || !looksLikePersonName(name, department)) continue;

        facultyFromJson.push({
          name,
          lastName: name.split(' ').pop() || name,
          email,
          title,
          profileUrl,
          isResearchActive: isResearchActiveFromText(title),
        });
      }

      const score = facultyFromJson.filter(f => f.isResearchActive && !!f.email).length * 10 + facultyFromJson.length;
      parsedCandidates.push({ url: r.url, faculty: facultyFromJson, score });
      console.log(`JSON extraction from ${r.url} produced ${facultyFromJson.length} entries (score ${score})`);
    }

    parsedCandidates.sort((a, b) => b.score - a.score);
    let allFaculty: FacultyMember[] = parsedCandidates[0]?.faculty || [];

    // Fallback: if JSON extraction didn't produce enough, do one markdown scrape + regex on best URL
    if (allFaculty.length < 3 && parsedCandidates[0]?.url) {
      console.log('JSON extraction was weak; trying markdown regex fallback on:', parsedCandidates[0].url);
      const md = await scrapeMarkdown(apiKey, parsedCandidates[0].url);
      if (md.ok && md.markdown && md.markdown.length < 200000) {
        allFaculty = extractFacultyFromMarkdown(md.markdown, parsedCandidates[0].url, department);
      }
    }

    // Deduplicate by email or name
    const seen = new Set<string>();
    const faculty = allFaculty.filter(f => {
      const key = f.email || f.name;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });

    console.log('Total unique faculty found:', faculty.length);
    console.log('Research-active faculty:', faculty.filter(f => f.isResearchActive).length);
    
    if (faculty.length > 0) {
      console.log('Sample faculty:', JSON.stringify(faculty.slice(0, 3), null, 2));
    }

    // (JSON extraction already attempted above)

    // Enrich missing emails via profile-page scraping and targeted search
    const enrichedFaculty = await enrichMissingEmails(apiKey, university, department, faculty);
    const researchActiveWithEmails = enrichedFaculty.filter(f => f.isResearchActive && !!f.email);

    console.log('After enrichment, research-active with emails:', researchActiveWithEmails.length);

    return new Response(
      JSON.stringify({ 
        success: true, 
        faculty: enrichedFaculty,
        totalFound: enrichedFaculty.length,
        researchActive: enrichedFaculty.filter(f => f.isResearchActive).length,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in scrape-faculty:', error);
    return new Response(
      JSON.stringify({ success: false, error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
