import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface FacultyMember {
  name: string;
  lastName: string;
  email: string | null;
  title: string;
  profileUrl: string;
  isResearchActive: boolean;
}

interface AnalyzedFaculty extends FacultyMember {
  researchInterests: string;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { faculty } = await req.json();
    console.log(`Analyzing research interests for ${faculty.length} faculty members`);

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) {
      return new Response(
        JSON.stringify({ success: false, error: "LOVABLE_API_KEY is not configured" }),
        { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Build a single prompt with all faculty members to avoid rate limiting
    const facultyList = faculty.map((m: FacultyMember, i: number) => 
      `${i + 1}. ${m.name} - ${m.title}`
    ).join('\n');

    console.log('Sending batch request to AI...');

    const aiResponse = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${LOVABLE_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          {
            role: "system",
            content: `You are an expert at inferring academic research interests from professor titles and departments.
Given a list of professors with their titles, output a JSON array with VERY BROAD research interests for each.

Rules:
- Each entry should have exactly 2 EXTREMELY BROAD, SIMPLE phrases separated by " and "
- Use the SIMPLEST possible language that a middle schooler would understand
- Focus on the big-picture field, NOT specific research topics
- DO NOT use technical jargon
- Keep each phrase to 2-4 words maximum

Output format (JSON array, one entry per professor in order):
["phrase1 and phrase2", "phrase1 and phrase2", ...]

Examples of GOOD broad phrases:
- "money and investing" (NOT "financial markets and investment strategies")
- "how businesses work" (NOT "corporate finance")
- "the economy" (NOT "macroeconomic policy")
- "computer science" (NOT "machine learning algorithms")
- "how the brain works" (NOT "cognitive neuroscience")
- "chemistry and medicine" (NOT "pharmaceutical chemistry")

Example output for 3 finance professors:
["money and investing", "banks and the economy", "business and finance"]`
          },
          {
            role: "user",
            content: `Generate research interests for these ${faculty.length} professors:\n\n${facultyList}`
          }
        ],
      }),
    });

    if (!aiResponse.ok) {
      const errorText = await aiResponse.text();
      console.error('AI API error:', aiResponse.status, errorText);
      
      // Fallback: generate generic interests based on department
      const analyzedFaculty: AnalyzedFaculty[] = faculty.map((member: FacultyMember) => ({
        ...member,
        researchInterests: inferFromTitle(member.title),
      }));
      
      console.log('Using fallback title-based inference');
      return new Response(
        JSON.stringify({ success: true, faculty: analyzedFaculty }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const aiData = await aiResponse.json();
    const content = aiData.choices?.[0]?.message?.content?.trim() || '[]';
    
    // Parse the JSON array from AI response
    let researchInterests: string[] = [];
    try {
      // Extract JSON from markdown code blocks if present
      const jsonMatch = content.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        researchInterests = JSON.parse(jsonMatch[0]);
      }
    } catch (e) {
      console.error('Failed to parse AI response, using fallback:', e);
    }

    // Map research interests back to faculty
    const analyzedFaculty: AnalyzedFaculty[] = faculty.map((member: FacultyMember, i: number) => ({
      ...member,
      researchInterests: researchInterests[i] || inferFromTitle(member.title),
    }));

    console.log(`Successfully analyzed ${analyzedFaculty.length} faculty members`);

    return new Response(
      JSON.stringify({ success: true, faculty: analyzedFaculty }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in analyze-research:', error);
    return new Response(
      JSON.stringify({ success: false, error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

// Fallback: infer research interests from title
function inferFromTitle(title: string): string {
  const lowerTitle = title.toLowerCase();
  
  if (lowerTitle.includes('finance')) return 'money and investing';
  if (lowerTitle.includes('economics')) return 'the economy and markets';
  if (lowerTitle.includes('accounting')) return 'business and finance';
  if (lowerTitle.includes('marketing')) return 'advertising and sales';
  if (lowerTitle.includes('management')) return 'business and leadership';
  if (lowerTitle.includes('computer') || lowerTitle.includes('data')) return 'computers and technology';
  if (lowerTitle.includes('operations')) return 'business and logistics';
  if (lowerTitle.includes('statistics')) return 'math and data';
  if (lowerTitle.includes('biology') || lowerTitle.includes('bio')) return 'biology and life science';
  if (lowerTitle.includes('chemistry') || lowerTitle.includes('chem')) return 'chemistry and molecules';
  if (lowerTitle.includes('physics')) return 'physics and the universe';
  if (lowerTitle.includes('math')) return 'mathematics and logic';
  if (lowerTitle.includes('psychology') || lowerTitle.includes('psych')) return 'the mind and behavior';
  if (lowerTitle.includes('sociology') || lowerTitle.includes('social')) return 'society and culture';
  if (lowerTitle.includes('history')) return 'history and the past';
  if (lowerTitle.includes('english') || lowerTitle.includes('literature')) return 'writing and literature';
  if (lowerTitle.includes('engineering')) return 'engineering and design';
  if (lowerTitle.includes('medicine') || lowerTitle.includes('medical')) return 'medicine and health';
  if (lowerTitle.includes('law')) return 'law and justice';
  if (lowerTitle.includes('political') || lowerTitle.includes('politics')) return 'politics and government';
  if (lowerTitle.includes('art') || lowerTitle.includes('design')) return 'art and creativity';
  if (lowerTitle.includes('music')) return 'music and sound';
  if (lowerTitle.includes('education')) return 'teaching and learning';
  if (lowerTitle.includes('environmental')) return 'the environment and nature';
  
  return 'academic research and innovation';
}
