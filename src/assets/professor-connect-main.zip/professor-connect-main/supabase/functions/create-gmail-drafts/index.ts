import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface AnalyzedFaculty {
  name: string;
  lastName: string;
  email: string | null;
  title: string;
  profileUrl: string;
  isResearchActive: boolean;
  researchInterests: string;
}

interface EmailDraft {
  professorName: string;
  email: string;
  subject: string;
  body: string;
  gmailComposeUrl: string;
  profileUrl?: string;
  success: boolean;
  error?: string;
}

const EMAIL_TEMPLATE = `Dear Professor {lastName},

I hope you are doing well. My name is Ethan Xie, and I am currently a high school student at The Charter School of Wilmington in Wilmington, Delaware. I am reaching out to inquire if there is a potential opportunity, paid or unpaid, for me to act as an intern or assistant for you, or if I could work alongside you with a potential research study. I am particularly interested in {researchInterests}, as well as data science and analytics.

I currently work with the Lemelson–MIT Program, assisting in the development of a Bluetooth-enabled ostomy leak alert and leading the system architecture design, including separating detection logic using convolutional neural network-based machine learning on an Arduino. Furthermore, I have extensive experience with C, C++, Python, Pandas, Tensorflow, and NumPy, alongside many other skills that could prove useful to you.

I also placed 2nd out of 250 teams internationally in the Financial Portfolio Management competition hosted by Business Professionals of America (BPA). In this competition, I led a team of 3 other students to create an investment strategy that maximized returns over 4 months. We valued companies through intrinsic and relative valuation methods and used metrics like the Sharpe ratio to evaluate the risk-adjusted performance of our portfolio. We ultimately achieved an 18% return through an aggressive equity allocation. In the final round, we presented our investment thesis and portfolio strategy to a panel of industry professionals, explaining our approach and answering any questions they had.

I am very enthusiastic about contributing to a potential research study or assisting you with your work, and I am confident that my experience would make me a valuable addition. I am willing to contribute up to 30 hours a week to assist with any tasks or projects you may need help with.

I would greatly appreciate your consideration if there is an opportunity for me. I thank you for your time and would be honored to discuss any potential opportunities with you further. Please let me know if there is a good time for us to meet or if you would like me to provide any documents or materials.

Additionally, I have attached my resume, which outlines more of my experience and background.

Hope to hear from you soon.

Sincerely,
Ethan Xie`;

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { faculty } = await req.json();
    console.log(`Creating email drafts for ${faculty.length} faculty members`);

    const drafts: EmailDraft[] = [];

    for (const member of faculty as AnalyzedFaculty[]) {
      const emailBody = EMAIL_TEMPLATE
        .replace('{lastName}', member.lastName)
        .replace('{researchInterests}', member.researchInterests);

      const subject = 'Inquiry About Research or Internship Opportunity';
      
      // Create Gmail compose URL
      const gmailComposeUrl = `https://mail.google.com/mail/?view=cm&fs=1&to=${encodeURIComponent(member.email || '')}&su=${encodeURIComponent(subject)}&body=${encodeURIComponent(emailBody)}`;

      const draft: EmailDraft = {
        professorName: member.name,
        email: member.email || '',
        subject,
        body: emailBody,
        gmailComposeUrl,
        profileUrl: member.profileUrl,
        success: !!member.email,
        error: member.email ? undefined : 'No email address found',
      };

      drafts.push(draft);
    }

    const successCount = drafts.filter(d => d.success).length;
    console.log(`Generated ${successCount}/${drafts.length} email drafts`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        drafts,
        successCount,
        totalCount: drafts.length,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Error in create-gmail-drafts:', error);
    return new Response(
      JSON.stringify({ success: false, error: error instanceof Error ? error.message : 'Unknown error' }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
